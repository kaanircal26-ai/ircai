# TOZRA API güvenlik paketi

Bu paket, konuşmada paylaşılan mevcut TOZRA API kodlarına dayanarak hazırlanmıştır. Dosyalar `api/` klasörüne yerleştirilmelidir.

## İçerik
- `api/_auth.js`: Supabase Auth üzerinden Bearer token doğrulaması; 10 saniye zaman aşımı.
- `api/_rate-limit.js`: Upstash Redis REST ile kullanıcı bazlı hız sınırlaması.
- `api/chat.js`: Mevcut sohbet işlevleri korunarak rate limit ve istek gövdesi boyut sınırı eklendi.
- `api/config.js`: Yalnızca Supabase URL ve publishable/anon anahtarını döndürür.
- `api/realtime-session.js`: Kullanıcı doğrulaması, hız sınırı, bağlam boyutu sınırı ve kısa zaman aşımı.
- `api/transcribe.js`: Kullanıcı doğrulaması, hız sınırı, Base64 ve ses boyutu doğrulaması.

## Vercel ortam değişkenleri
Mevcut değişkenlerinizi koruyun:
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY` (veya eski kurulumlarda `SUPABASE_ANON_KEY`)
- `GROQ_API_KEY`
- `TAVILY_API_KEY`
- `OPENAI_API_KEY`

### Hız sınırlaması için ek değişkenler
Upstash Redis REST veritabanı oluşturup şunları Vercel Project Settings → Environment Variables bölümüne ekleyin:
- `UPSTASH_REDIS_REST_URL`
- `UPSTASH_REDIS_REST_TOKEN`
- `RATE_LIMIT_FAIL_CLOSED=true` (önerilir; Redis ayarlı değilse veya erişilemiyorsa korunan endpoint'ler geçici olarak 503 döndürür)

Upstash değişkenleri eklenmeden paket varsayılan olarak hız sınırlamasını devre dışı bırakır; bu, ilk deploy'da uygulamanın bozulmaması içindir. Canlıya almadan önce Upstash ayarlarını tamamlayın ve `RATE_LIMIT_FAIL_CLOSED=true` yapın.

## Kurulum
1. Mevcut GitHub deposunun bir yedeğini alın.
2. ZIP içindeki `api/` klasörünün içeriğini deponuzdaki `api/` klasörüne kopyalayın.
3. Vercel ortam değişkenlerini kontrol edin ve Upstash değişkenlerini ekleyin.
4. GitHub'a commit/push yapın; Vercel dağıtımının tamamlanmasını bekleyin.
5. Önce test ortamında yazılı sohbet, sesli oturum ve ses transkripsiyonunu deneyin.

## Önemli sınırlar ve doğrulama notları
- Supabase publishable/anon anahtarı istemciye açık olabilir; `service_role` veya secret key'i asla `config.js` üzerinden döndürmeyin.
- Bu paket, sohbet geçmişi/hafıza/proje bağlamı gibi istemciden gelen metinleri güvenilir kimlik kanıtı saymaz; bunlar hâlâ içerik girdisidir. Özel verileri sunucuda doğrudan veritabanından yüklemek için gerçek frontend istek sözleşmesi ve tablo şemaları ayrıca eşleştirilmelidir.
- RLS'nin açık olması tek başına yeterli değildir; her tabloda `auth.uid() = user_id` gibi doğru SELECT/INSERT/UPDATE/DELETE politikaları ve gerekiyorsa `WITH CHECK` şartları ayrıca incelenmelidir. Bu ZIP mevcut veritabanı politikalarını değiştirmez.
- `config.js` kasıtlı olarak kimlik doğrulamasızdır çünkü publishable/anon anahtar yapı gereği istemciye verilir.
- Bu paket statik kod incelemesine göre hazırlanmıştır; gerçek Vercel ortamında çalıştırılmış entegrasyon veya penetrasyon testi değildir. Önce yedek ve staging/test dağıtımı kullanın.
