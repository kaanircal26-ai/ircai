async function requireUser(req, res) {
  const authorization = req.headers.authorization || "";
  const match = authorization.match(/^Bearer\s+([^\s]+)$/i);

  if (!match || match[1].length > 8192) {
    res.status(401).json({ success: false, error: "Bu işlem için TOZRA hesabına giriş yapmalısın." });
    return null;
  }

  const supabaseUrl = process.env.SUPABASE_URL;
  const supabaseKey = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY;
  if (!supabaseUrl || !supabaseKey) {
    res.status(503).json({ success: false, error: "Supabase sunucu yapılandırması eksik." });
    return null;
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetch(`${supabaseUrl.replace(/\/+$/, "")}/auth/v1/user`, {
      method: "GET",
      headers: { apikey: supabaseKey, Authorization: `Bearer ${match[1]}` },
      signal: controller.signal
    });
    if (!response.ok) {
      res.status(401).json({ success: false, error: "Oturumun geçersiz veya süresi dolmuş. Lütfen yeniden giriş yap." });
      return null;
    }
    const user = await response.json();
    if (!user || typeof user.id !== "string" || !user.id) {
      res.status(401).json({ success: false, error: "Kullanıcı oturumu doğrulanamadı." });
      return null;
    }
    return user;
  } catch (error) {
    console.error("Supabase auth doğrulama hatası:", error.name === "AbortError" ? "timeout" : error.message);
    res.status(error.name === "AbortError" ? 504 : 502).json({
      success: false,
      error: error.name === "AbortError" ? "Hesap doğrulaması zaman aşımına uğradı." : "Hesap doğrulama servisine ulaşılamadı."
    });
    return null;
  } finally {
    clearTimeout(timeout);
  }
}
module.exports = { requireUser };
