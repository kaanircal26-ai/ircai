async function enforceRateLimit({ userId, route, limit, windowSeconds }) {
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  const failClosed = String(process.env.RATE_LIMIT_FAIL_CLOSED || "false").toLowerCase() === "true";

  if (!url || !token) {
    return failClosed
      ? { allowed: false, unavailable: true, retryAfter: windowSeconds }
      : { allowed: true, configured: false };
  }

  const key = `tozra:rate:${route}:${userId}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch(url.replace(/\/+$/, ""), {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(["INCR", key]),
      signal: controller.signal
    });
    if (!response.ok) throw new Error(`rate-limit HTTP ${response.status}`);
    const data = await response.json();
    const count = Number(data.result);
    if (!Number.isFinite(count)) throw new Error("invalid rate-limit response");

    if (count === 1) {
      const expireResponse = await fetch(url.replace(/\/+$/, ""), {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(["EXPIRE", key, windowSeconds]),
        signal: controller.signal
      });
      if (!expireResponse.ok) throw new Error(`rate-limit expiry HTTP ${expireResponse.status}`);
    }

    return {
      allowed: count <= limit,
      retryAfter: windowSeconds,
      remaining: Math.max(0, limit - count),
      configured: true
    };
  } catch (error) {
    console.error("Rate limit service error:", error.name === "AbortError" ? "timeout" : error.message);
    return failClosed
      ? { allowed: false, unavailable: true, retryAfter: windowSeconds }
      : { allowed: true, configured: false, serviceError: true };
  } finally {
    clearTimeout(timeout);
  }
}
module.exports = { enforceRateLimit };
