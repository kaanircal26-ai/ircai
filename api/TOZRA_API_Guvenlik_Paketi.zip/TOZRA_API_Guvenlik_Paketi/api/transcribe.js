const { requireUser } = require("./_auth");
const { enforceRateLimit } = require("./_rate-limit");

module.exports = async function handler(req, res) {
  const user = await requireUser(req, res);
  if (!user) return;
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ success: false, error: "Sadece POST isteği destekleniyor." });
  }

  const rate = await enforceRateLimit({ userId: user.id, route: "transcribe", limit: 10, windowSeconds: 60 });
  if (!rate.allowed) {
    res.setHeader("Retry-After", String(rate.retryAfter || 60));
    return res.status(rate.unavailable ? 503 : 429).json({ success: false, error: rate.unavailable ? "İstek güvenlik servisi şu anda kullanılamıyor." : "Çok fazla ses dönüştürme isteği gönderdin. Biraz bekle." });
  }

  try {
    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey) return res.status(500).json({ success: false, error: "Ses hizmeti sunucu ayarlarında yapılandırılmamış." });
    const body = req.body || {};
    if (Buffer.byteLength(JSON.stringify(body), "utf8") > 5 * 1024 * 1024) {
      return res.status(413).json({ success: false, error: "Ses isteği çok büyük." });
    }
    const audio = body.audio;
    const mimeType = typeof body.mimeType === "string" ? body.mimeType : "audio/webm";
    if (typeof audio !== "string" || !audio.length) return res.status(400).json({ success: false, error: "Ses kaydı gönderilmedi." });

    const allowedTypes = ["audio/webm", "audio/mp4", "audio/ogg", "audio/wav", "audio/mpeg", "audio/mpga", "audio/m4a"];
    const normalizedType = mimeType.split(";")[0].toLowerCase();
    if (!allowedTypes.includes(normalizedType)) return res.status(400).json({ success: false, error: "Desteklenmeyen ses formatı." });
    if (audio.length > 4 * 1024 * 1024 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(audio)) {
      return res.status(400).json({ success: false, error: "Ses verisi geçersiz." });
    }
    const buffer = Buffer.from(audio, "base64");
    if (!buffer.length || buffer.length > 3 * 1024 * 1024 || buffer.toString("base64") !== audio) {
      return res.status(413).json({ success: false, error: "Ses kaydı geçersiz veya 3 MB sınırını aşıyor." });
    }

    const extension = normalizedType === "audio/mp4" || normalizedType === "audio/m4a" ? "m4a"
      : normalizedType === "audio/ogg" ? "ogg" : normalizedType === "audio/wav" ? "wav"
      : normalizedType === "audio/mpeg" || normalizedType === "audio/mpga" ? "mp3" : "webm";
    const form = new FormData();
    form.append("file", new Blob([buffer], { type: normalizedType }), `tozra-voice.${extension}`);
    form.append("model", "whisper-large-v3-turbo");
    form.append("language", "tr");
    form.append("response_format", "json");
    form.append("temperature", "0");

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 60000);
    let response;
    try {
      response = await fetch("https://api.groq.com/openai/v1/audio/transcriptions", {
        method: "POST", headers: { Authorization: `Bearer ${apiKey}` }, body: form, signal: controller.signal
      });
    } finally { clearTimeout(timeout); }

    const raw = await response.text();
    let result;
    try { result = JSON.parse(raw); } catch {
      return res.status(502).json({ success: false, error: "Ses servisi geçerli bir yanıt vermedi." });
    }
    if (!response.ok) {
      console.error("Groq transcription error:", response.status, result.error?.type || "unknown");
      return res.status(response.status === 429 ? 429 : 502).json({ success: false, error: "Ses yazıya dönüştürülemedi." });
    }
    const text = typeof result.text === "string" ? result.text.trim() : "";
    if (!text) return res.status(502).json({ success: false, error: "Konuşmadan metin çıkarılamadı." });
    return res.status(200).json({ success: true, text, model: "whisper-large-v3-turbo" });
  } catch (error) {
    console.error("TOZRA transcription error:", error.name === "AbortError" ? "timeout" : error.message);
    return res.status(error.name === "AbortError" ? 504 : 500).json({ success: false, error: error.name === "AbortError" ? "Ses işleme zaman aşımına uğradı." : "Ses işlenirken beklenmeyen bir hata oluştu." });
  }
};
